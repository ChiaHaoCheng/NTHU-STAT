#' Data B
#'
#' DataB from statistical computing HW4
#' @format A data frame with 100 rows and 2 variables:
#'  \describe{
#'      \item{X}{index}
#'      \item{x}{x}
#'      }
#'
#' @source {National Tsing Hua University Institute of Statistics}
#'
#' @examples
#'   data("DataB")
"DataB"
